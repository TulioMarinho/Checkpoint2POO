public class Clientes {
    private String nome;
    private String cpf;


    public Clientes() {

    }
// Para que seja feita uma venda, o cliente deve se identificar, colocando seu nome e cpf.

    public Clientes(String nome, String cpf) {
        this.nome = nome;
        this.cpf = cpf;
    }

}
