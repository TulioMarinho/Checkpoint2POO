public class Produtos {
    private String tipo;
    private String nomeProduto;
    private double valor;

    // Para cadastrar o Produto, antes é necessário cadastrar o tipo, o nome do produto e o valor.
    public Produtos(String tipo, String nomeProduto, double valor) {
        this.tipo = tipo;
        this.nomeProduto = nomeProduto;
        this.valor = valor;
    }





    public String getTipo(){
        return this.tipo ;
    }

    public double getValor(){
        return this.valor ;
    }

}
