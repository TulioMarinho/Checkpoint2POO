

public class Estoque {
    private int cod;
    private  Produtos produto;
    private int quantidade;



    public Estoque() {
    }

    // Para que um produto conste no estoque, antes é necessário passar o código do produto, o produto e a quantidade desejada.
    public Estoque(int cod, Produtos produto, int quantidade) {
        this.cod = cod;
        this.produto = produto;
        this.quantidade = quantidade;
    }

    // O método calcularValor, vai calcular o valor total do estoque, usando as variáveis "quantidade" e "produto".

    public void calcularValor () {
        double resultado = this.quantidade * this.produto.getValor();
        System.out.println("O valor em estoque é de:......." + resultado);
    }

    //  O método incluirItem, vai incluir um item no Estoque, e calcular a quantidade, com a variável "quantidade".


    public void incluirItem ( int quantidade) {
        this.quantidade += quantidade;
        System.out.println("A quantidade atual de produtos e :" + this.quantidade);
    }

    // O método subtrairItem, subtrai o item desejado do Estoque, com a variável "quantidade".

    public void subtrairItem(int quantidade){
        this.quantidade -= quantidade ;
        System.out.println("A quantidade atual de produtos e :" + this.quantidade);
    }


    public int getQuantidade(){
        return this.quantidade ;
    }

    public Produtos getProduto(){
        return this.produto ;
    }

}