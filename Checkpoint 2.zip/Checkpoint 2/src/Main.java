import java.util.Scanner;


class Main {
    public static void main(String[] args) {

        // O método Scanner é utilizado para que o usuário consiga inserir dados dentro do sistema.
        Scanner entrada = new Scanner(System.in);

        // Utilizando o Scanner, o usuário insere os dados, que serão armazenados na classe Produtos.
        System.out.println("Digite o nome do produto  ");
        String nomeProduto = entrada.nextLine();

        System.out.println("Digite o tipo do produto: ");
        String  tipoProduto = entrada.nextLine();

        System.out.println("Digite o preço do produto : ");
        double valor = entrada.nextDouble();

        //Aqui é onde estão instanciadas as variáveis que o usuário inseriu.
        Produtos produto1 = new Produtos(tipoProduto, nomeProduto ,valor );

        Estoque estoque = new Estoque(1,produto1, 22);

        estoque.calcularValor();

        Pedido pedido = new Pedido(10, estoque);

        pedido.enviarProduto();

        Clientes cliente = new Clientes("João" , "0577774531414");

        Vendas venda = new Vendas(10,estoque, cliente);

        System.out.println("Digite a quantidade de itens que devem ser adicionados no estoque: ........");
        int itemEstoque = entrada.nextInt();

        estoque.incluirItem(itemEstoque);
        estoque.subtrairItem(5);
        estoque.getQuantidade();



    }
}

