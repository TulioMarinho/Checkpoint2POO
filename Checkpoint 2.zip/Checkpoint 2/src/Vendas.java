import java.util.List;
import java.util.ArrayList;


public class Vendas{

    private int quantidadeProdut;
    private double valor;
    private Estoque estoque;
    private Clientes cliente ;
    private int numeroVendas ;

    private ArrayList<Produtos> listaProdutos = new ArrayList<>();

    // Para que uma venda seja efetuada, tem que informar a quantidade de produtos vendidos, e o cliente que irá comprar o produto.
    public Vendas(int quantidadeProdut, Estoque estoque , Clientes cliente) {
        this.quantidadeProdut = quantidadeProdut;
        this.cliente = cliente;
        this.estoque = estoque;
        this.listaProdutos.add(estoque.getProduto());
        this.valor = quantidadeProdut * estoque.getProduto().getValor();
        this.numeroVendas ++ ;
    }

    // O método totalVendas, informa o total de vendas que foram feitas.
    public void totalVendas () {
        System.out.println("O total de vendas é:" + this.numeroVendas);
    }

    // O método produtosVendidos, informa quais são os produtos vendidos.

    public void produtosVendidos () {
        System.out.println("Os produtos vendidos são: " + this.listaProdutos);
    }

    // O método subtrairEstoque, vai subtrair os itens vendidos do estoque, para que possam ser repostos.
    public void subtrairEstoque () {
        this.estoque.subtrairItem(this.quantidadeProdut);
        System.out.println("Os produtos que restam no estoque são:"+ this.estoque.getQuantidade());
    }

}
