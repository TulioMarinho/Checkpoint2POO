
public class Pedido {


    private int cod;
    private String tipoProduto;
    private int quantidade;
    private double valor;
    private Estoque estoque ;

    // Para que um pedido seja realizado, antes é necessário passar a quantidade, o tipo e o valor.
    public Pedido(int quantidade, Estoque estoque) {
        this.quantidade = quantidade;
        this.estoque = estoque ;
        this.tipoProduto = estoque.getProduto().getTipo();
        double valorProduto = estoque.getProduto().getValor() ;
        this.valor = (quantidade)*valorProduto ;
    }

    // O método enviarProduto, vai enviar o produto para o Estoque, de forma que nunca falte itens.

    public  void enviarProduto () {
        this.estoque.incluirItem(this.quantidade);
        System.out.println("O produto foi enviado:\n .......");
    }


}